setConstructorS3("FileByteMatrix", function(...) {
  extend(FileMatrix(..., bytesPerCell=1, storageMode="integer"), "FileByteMatrix")
})

############################################################################
# HISTORY:
# 2006-01-22
# o Created.
############################################################################ 
