setConstructorS3("FileDoubleMatrix", function(...) {
  extend(FileMatrix(..., bytesPerCell=8, storageMode="double"), "FileDoubleMatrix")
})


############################################################################
# HISTORY:
# 2006-01-22
# o Created.
############################################################################ 
