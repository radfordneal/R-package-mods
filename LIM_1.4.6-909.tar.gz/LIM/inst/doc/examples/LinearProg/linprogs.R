###############################################
# To read the files in this directory:
# First set the working directory
# setwd("    LIM/examples/Foodweb")
###############################################

Linp("vanderbei1.input", verbose = TRUE)
vdb <- Setup("vanderbei1.input", verbose = TRUE)

Linp("vanderbei2.input", verbose = FALSE)
Linp("blending.input", verbose = FALSE)
Linp("greenberg1.input", verbose = FALSE)
Linp("refinery.001", verbose = FALSE)
Linp("simple.input", verbose = FALSE)
Linp("vanderbei3.input", verbose = FALSE)
Linp("vanderbei4.input", verbose = FALSE)
Linp("vanderbei5.input", verbose = FALSE)
Linp("manpower.001", verbose = FALSE)
Linp("foodmanufacture.001", verbose = FALSE)
Linp("machines.input", verbose = FALSE)
Linp("diet.input", verbose = FALSE)
Linp("alloymixture.input", verbose = FALSE)
Linp("transportation.input", verbose = FALSE)



