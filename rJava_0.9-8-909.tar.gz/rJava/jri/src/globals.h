#ifndef __GLOBALS__H__
#define __GLOBALS__H__

#include <jni.h>

extern jobject engineObj;
extern jclass engineClass;
extern JNIEnv *eenv;

#endif
