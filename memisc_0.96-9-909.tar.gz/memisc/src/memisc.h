FILE *get_FILE(SEXP);
void trim (char *, int);
int ftell32 (FILE *f);
