
void C_surrogates(SEXP node, SEXP learnsample, SEXP weights, SEXP controls, SEXP fitmem);
void C_splitsurrogate(SEXP node, SEXP learnsample);
