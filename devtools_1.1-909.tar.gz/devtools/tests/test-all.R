library(testthat)
library(devtools)

test_package("devtools")
