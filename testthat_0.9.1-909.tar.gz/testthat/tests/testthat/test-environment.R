context("Environment")

setClass("MyClass")

test_that("Can create S4 class without special behaviour", {
  setClass("MyClass2")

})
