"summary.scan.gwaa" <- 
		function(object,...) {
	ret <- descriptives.scan(object, ... )
	ret
}
