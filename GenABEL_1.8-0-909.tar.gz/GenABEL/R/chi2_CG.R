chi2_CG <- function(...)
{
	out <- cocohet(...)
	out
}